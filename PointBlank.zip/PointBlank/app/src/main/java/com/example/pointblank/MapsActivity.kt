package com.example.pointblank

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.pointblank.databinding.ActivityMapsBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices.getFusedLocationProviderClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.Task

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var locationClient: LocationClient


    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationProviderClient = getFusedLocationProviderClient(this)
        locationClient = DefaultLocation(applicationContext, getFusedLocationProviderClient(applicationContext))

            setOnClickListener()

    }


    private fun setOnClickListener(){
        binding.Refreash.setOnClickListener{buttonTapped(it)}
    }

    @SuppressLint("MissingPermission")
    private fun buttonTapped(v: View){
        when(v){
            binding.Refreash -> {
                if( permissionCheck()){
                    val task: Task<Location> = fusedLocationProviderClient.lastLocation
                    task.addOnSuccessListener {
                        var lnt: Double = it.latitude
                        var lng: Double = it.longitude
                        var latlng: LatLng = LatLng(lnt, lng)
                        mMap.addMarker(MarkerOptions().position(latlng))
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(latlng))
                        Toast.makeText(this, "Latitude: $lnt, Longitude $lng", Toast.LENGTH_LONG).show()
                    }

                }
                else {
                    Toast.makeText(this,"Please update required accesses", Toast.LENGTH_LONG).show()
                    permissionCheck()

                }
            }

        }

    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.mMap = googleMap
        mMap.mapType = GoogleMap.MAP_TYPE_HYBRID

       this.startService(Intent(applicationContext, LocationService::class.java))

        val task: Task<Location> = fusedLocationProviderClient.lastLocation
        if (
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.FOREGROUND_SERVICE
                ), 2
            )

        }


        task.addOnSuccessListener {
            if (it != null) {
                val lat: Double = it.latitude
                val lng: Double = it.longitude
                val spot = LatLng(lat, lng)
                mMap.addMarker(MarkerOptions().position(spot))
                mMap.moveCamera(CameraUpdateFactory.newLatLng(spot))
                Toast.makeText(this, "Latitude: $lat, Longitude $lng", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun permissionCheck() : Boolean {
        if (
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED) {
            return false
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.FOREGROUND_SERVICE
                ), 1
            )
            return true
        }
        }

    }






























































