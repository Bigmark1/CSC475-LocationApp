package com.example.pointblank

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
@Suppress("DEPRECATION")
class DefaultLocation(private val context: Context, private val client:
FusedLocationProviderClient):LocationClient {
 //   @SuppressLint("MissingPermission")


    @SuppressLint("MissingPermission")
    override fun getLocationUpdates(interval: Long): Flow<Location> {
        return callbackFlow {

            if (!context.hasLocationPermission()
            ) {

                throw LocationClient.LocationException("Missing location permission")
            }
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as
                    LocationManager

            val gpsAvailable = locationManager.isProviderEnabled(Context.LOCATION_SERVICE)
            val netWorkAvailable =
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (!gpsAvailable && !netWorkAvailable) {
                throw LocationClient.LocationException("Required networks are not available")
            }


            val request =
                com.google.android.gms.location.LocationRequest.create().setInterval(interval)
                    .setFastestInterval(interval)

            val locationCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    super.onLocationResult(result)
                    result.locations.lastOrNull()?.let { location ->
                        launch { send(location) }
                    }
                }

            }

            client.requestLocationUpdates(
                request,
                locationCallback,
                Looper.getMainLooper()

            )

            awaitClose {
                client.removeLocationUpdates(locationCallback)
            }
        }
    }


}

