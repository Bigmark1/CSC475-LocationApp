package com.example.pointblank


import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.pointblank.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onEach



class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mapsActivity: MapsActivity = MapsActivity()
    private var b: Boolean = false



    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val b: Boolean = this.hasLocationPermission()
        if(b == false){
            dialogBuilder()


        }





    }


    fun toMap(v: View){
            this.startActivity(Intent(applicationContext, MapsActivity::class.java))
            startActivity(intent)

    }

    fun yes() {
        if (
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.FOREGROUND_SERVICE
                ), 1
            )
        }
        startActivity(intent)

    }





    fun dialogBuilder() {


        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setMessage(
                "PointBlank requires Fine and Approximate access to your location.\n " +
                        "Would you like to grant access now? "
            )
            .setTitle("!!Location!!!")
            .setPositiveButton("Yes") { dialog, which ->
                yes()
                this.b = true
            }
            .setNegativeButton("No") { dialog, which ->
                Toast.makeText(this, "Unable to proceed", Toast.LENGTH_LONG).show()
                this.b = false
            }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

}










































